import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditEmployee = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [employee, setEmployee] = useState(null);

    useEffect(() => {
        const employees = JSON.parse(localStorage.getItem("employees")) || [];
        const emp = employees.find(e => e.id === Number(id));
        setEmployee(emp);
    }, [id]);

    const handleChange = (e) => {
        setEmployee({ ...employee, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const employees = JSON.parse(localStorage.getItem("employees")) || [];
        const updated = employees.map(emp =>
            emp.id === Number(id) ? employee : emp
        );

        localStorage.setItem("employees", JSON.stringify(updated));
        navigate("/employees");
    };

    if (!employee) return null;

    return (
        <div className="page">
            <h2 className="title">Edit Employee</h2>

            <form className="form" onSubmit={handleSubmit}>
                <input name="name" value={employee.name} onChange={handleChange} />
                <input name="email" value={employee.email} onChange={handleChange} />
                <input name="role" value={employee.role} onChange={handleChange} />
                <input name="salary" value={employee.salary} onChange={handleChange} />
                <input name="image" value={employee.image} onChange={handleChange} />

                <button>Update Employee</button>
            </form>
        </div>
    );
};

export default EditEmployee;
