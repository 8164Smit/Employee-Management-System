import { useState } from "react";
import { useNavigate } from "react-router-dom";

const AddEmployee = () => {
    const navigate = useNavigate();

    const [employee, setEmployee] = useState({
        name: "",
        email: "",
        role: "",
        salary: "",
        image: ""
    });

    const handleChange = (e) => {
        setEmployee({ ...employee, [e.target.name]: e.target.value });
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onloadend = () => {
            setEmployee(prev => ({
                ...prev,
                image: reader.result
            }));
        };

        reader.readAsDataURL(file);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const employees = JSON.parse(localStorage.getItem("employees")) || [];
        employees.push({ ...employee, id: Date.now() });

        localStorage.setItem("employees", JSON.stringify(employees));
        navigate("/employees");
    };

    return (
        <div className="page">
            <h2 className="title">Add Employee</h2>

            <form className="form" onSubmit={handleSubmit}>
                <input
                    name="name"
                    placeholder="Employee Name"
                    onChange={handleChange}
                    required
                />

                <input
                    name="email"
                    placeholder="Email"
                    onChange={handleChange}
                    required
                />

                <input
                    name="role"
                    placeholder="Role"
                    onChange={handleChange}
                    required
                />

                <input
                    name="salary"
                    placeholder="Salary"
                    onChange={handleChange}
                    required
                />

                <label className="file-label">
                    Upload Photo
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        hidden
                    />
                </label>

                {employee.image && (
                    <img
                        src={employee.image}
                        alt="preview"
                        className="preview-img"
                    />
                )}

                <button>Add Employee</button>
            </form>
        </div>
    );
};

export default AddEmployee;
