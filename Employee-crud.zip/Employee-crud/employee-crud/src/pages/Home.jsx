import { useEffect, useState } from "react";

const Home = () => {
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        const data = JSON.parse(localStorage.getItem("employees")) || [];
        setEmployees(data);
    }, []);

    return (
        <div className="page">
            <h2 className="title">Employee Management System</h2>

            <div className="card-container">
                {employees.map(emp => (
                    <div className="card" key={emp.id}>
                        <img
                            src={emp.image || "https://i.pravatar.cc/150"}
                            alt="employee"
                        />
                        <h3>{emp.name}</h3>
                        <p>{emp.role}</p>
                        <span>₹ {emp.salary}</span>
                    </div>
                ))}

                {employees.length === 0 && (
                    <p style={{ marginTop: "20px" }}>No Employees Added</p>
                )}
            </div>
        </div>
    );
};

export default Home;
