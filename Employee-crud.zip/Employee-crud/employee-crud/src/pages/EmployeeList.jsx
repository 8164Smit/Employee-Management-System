import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const EmployeeList = () => {
    const [employees, setEmployees] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const data = JSON.parse(localStorage.getItem("employees")) || [];
        setEmployees(data);
    }, []);

    const handleDelete = (id) => {
        if (!window.confirm("Are you sure you want to delete?")) return;

        const updated = employees.filter(emp => emp.id !== id);
        setEmployees(updated);
        localStorage.setItem("employees", JSON.stringify(updated));
    };

    // EDIT EMPLOYEE
    const handleEdit = (id) => {
        navigate(`/edit/${id}`);
    };

    return (
        <div className="page">
            <h2 className="title">Employee List</h2>

            <div className="employee-table-container">
                <table className="employee-table">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Salary</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {employees.length === 0 ? (
                            <tr>
                                <td colSpan="6">No Employees Found</td>
                            </tr>
                        ) : (
                            employees.map(emp => (
                                <tr key={emp.id}>
                                    <td>
                                        <img
                                            src={emp.image || "https://i.pravatar.cc/150"}
                                            className="employee-photo"
                                            alt="emp"
                                        />
                                    </td>
                                    <td>{emp.name}</td>
                                    <td>{emp.email}</td>
                                    <td>{emp.role}</td>
                                    <td>₹ {emp.salary}</td>
                                    <td>
                                        <button
                                            className="action-btn edit-btn"
                                            onClick={() => handleEdit(emp.id)}
                                        >
                                            Edit
                                        </button>

                                        <button
                                            className="action-btn delete-btn"
                                            onClick={() => handleDelete(emp.id)}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default EmployeeList;
